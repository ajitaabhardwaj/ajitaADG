import UIKit
func floyds(num : Int)
{
print("\n Floyd's Triangle \n");
var k = 1;
for i in 1...6
 {
    for _ in 1...i
    {
        print (k, terminator:" ");
        k=k+1;
     }
    print();
 }
    
}

func fibonacci(n : Int) {
    print("\n Fibonacci series \n");
    var a = 0;
    var b = 1;
    print (a);
    print (b);
    for _ in 1...n
    {
        var c = a+b;
        a = b;
        b = c;
        print(c);
    }
    
    
    }

floyds(num:5);
fibonacci(n:5);
